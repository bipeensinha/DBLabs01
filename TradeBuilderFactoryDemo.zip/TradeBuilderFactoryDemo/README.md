# Trade Builder & Factory Demo (Plain Java)

## Objective
Learn two design patterns:
1. Builder Pattern
2. Factory Pattern

No Spring, Maven, or external libraries are required.

## Project Structure

TradeBuilderFactoryDemo/
└── src
    ├── Main.java
    ├── Trade.java
    ├── TradeBuilder.java
    ├── TradeFactory.java
    └── InvalidTradeException.java

## Pattern 1 - Builder

The Builder constructs an object step-by-step.

Example:

Trade trade = new TradeBuilder()
    .tradeRef("TRD1001")
    .symbol("AAPL")
    .quantity(100)
    .price(180.50)
    .build();

Benefits:
- Easy to read
- Fluent API
- Validation before object creation

## Pattern 2 - Factory

The Factory hides object creation.

Example:

Trade trade = TradeFactory.createTrade(
    "TRD2001","IBM",50,210.75);

Benefits:
- Centralized object creation
- Easier maintenance
- Cleaner client code

## Compile

Open a terminal in the src folder.

javac *.java

## Run

java Main

## Expected Output

=== Builder Pattern ===
Trade Ref : TRD1001
Symbol    : AAPL
Quantity  : 100
Price     : 180.5

=== Factory Pattern ===
Trade Ref : TRD2001
Symbol    : IBM
Quantity  : 50
Price     : 210.75

## Suggested Classroom Activity

Step 1:
Run the project.

Step 2:
Modify quantity and price.

Step 3:
Remove tradeRef and observe the validation exception.

Step 4:
Add a new field (counterparty) to Trade and update the Builder.

Step 5:
Discuss:
- Why is Builder better than a long constructor?
- Why use a Factory instead of calling new everywhere?
