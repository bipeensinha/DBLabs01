public class Trade {
    private String tradeRef;
    private String symbol;
    private int quantity;
    private double price;

    public Trade(String tradeRef, String symbol, int quantity, double price) {
        this.tradeRef = tradeRef;
        this.symbol = symbol;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Trade Ref : " + tradeRef +
               "\nSymbol    : " + symbol +
               "\nQuantity  : " + quantity +
               "\nPrice     : " + price;
    }
}
