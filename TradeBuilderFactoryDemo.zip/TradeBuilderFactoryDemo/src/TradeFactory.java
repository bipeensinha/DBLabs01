public class TradeFactory {
    public static Trade createTrade(String tradeRef,String symbol,int quantity,double price){
        return new TradeBuilder()
                .tradeRef(tradeRef)
                .symbol(symbol)
                .quantity(quantity)
                .price(price)
                .build();
    }
}
