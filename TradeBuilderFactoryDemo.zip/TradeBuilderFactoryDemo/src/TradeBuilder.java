public class TradeBuilder {
    private String tradeRef;
    private String symbol;
    private int quantity;
    private double price;

    public TradeBuilder tradeRef(String tradeRef){ this.tradeRef=tradeRef; return this; }
    public TradeBuilder symbol(String symbol){ this.symbol=symbol; return this; }
    public TradeBuilder quantity(int quantity){ this.quantity=quantity; return this; }
    public TradeBuilder price(double price){ this.price=price; return this; }

    public Trade build(){
        if(tradeRef==null || symbol==null){
            throw new InvalidTradeException("Trade Ref and Symbol are required.");
        }
        return new Trade(tradeRef,symbol,quantity,price);
    }
}
