public class Main {
    public static void main(String[] args) {

        System.out.println("=== Builder Pattern ===");
        Trade trade1 = new TradeBuilder()
                .tradeRef("TRD1001")
                .symbol("AAPL")
                .quantity(100)
                .price(180.50)
                .build();

        System.out.println(trade1);

        System.out.println("\n=== Factory Pattern ===");

        Trade trade2 = TradeFactory.createTrade(
                "TRD2001",
                "IBM",
                50,
                210.75);

        System.out.println(trade2);
    }
}
