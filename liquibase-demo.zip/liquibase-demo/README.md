# Liquibase Demo (Beginner)

1. Open this project in VS Code.
2. Update liquibase.properties with your database details.
3. Run:

   liquibase update

4. Verify:

   SELECT * FROM customers;
   SELECT * FROM DATABASECHANGELOG;
