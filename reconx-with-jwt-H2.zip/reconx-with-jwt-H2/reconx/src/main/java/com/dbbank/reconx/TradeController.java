package com.dbbank.reconx;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TradeController {

    private final TradeRepository repository;

    public TradeController(TradeRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/trades")
    public List<Trade> getTrades() {
        return repository.getAllTrades();
    }
}