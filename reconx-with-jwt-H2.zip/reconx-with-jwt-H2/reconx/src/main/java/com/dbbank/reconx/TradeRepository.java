package com.dbbank.reconx;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TradeRepository {

    private final JdbcTemplate jdbcTemplate;

    public TradeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Trade> getAllTrades() {

        String sql = """
                SELECT trade_id,
                       trade_ref,
                       instrument,
                       quantity,
                       price
                FROM trade
                """;

        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new Trade(
                        rs.getInt("trade_id"),
                        rs.getString("trade_ref"),
                        rs.getString("instrument"),
                        rs.getInt("quantity"),
                        rs.getDouble("price")
                ));
    }
}