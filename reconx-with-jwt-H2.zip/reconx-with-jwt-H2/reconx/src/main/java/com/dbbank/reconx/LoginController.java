package com.dbbank.reconx;

import org.springframework.web.bind.annotation.*;

@RestController
public class LoginController {

    private final JwtService jwtService;

    public LoginController(JwtService jwtService){
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request){

        if(request.getUsername().equals("admin")
                && request.getPassword().equals("admin")){

            return jwtService.generateToken(request.getUsername());
        }

        return "Invalid Username or Password";
    }
}