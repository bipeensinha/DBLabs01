package com.dbbank.reconx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReconxApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReconxApplication.class, args);
	}

}
