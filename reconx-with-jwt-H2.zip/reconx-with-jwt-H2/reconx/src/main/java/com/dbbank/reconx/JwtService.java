package com.dbbank.reconx;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import org.springframework.stereotype.Service;

@Service
public class JwtService {

    private final SecretKey key =
            Keys.hmacShaKeyFor(
                    "12345678901234567890123456789012"
                    .getBytes(StandardCharsets.UTF_8));

    public String generateToken(String username){

        return Jwts.builder()
                .subject(username)
                .claim("role","ADMIN")
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis()+600000))
                .signWith(key)
                .compact();
    }
}