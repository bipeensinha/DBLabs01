package com.dbbank.reconx;

public class Trade {

    private Integer tradeId;
    private String tradeRef;
    private String instrument;
    private Integer quantity;
    private Double price;

    public Trade() {
    }

    public Trade(Integer tradeId, String tradeRef,
                 String instrument, Integer quantity,
                 Double price) {
        this.tradeId = tradeId;
        this.tradeRef = tradeRef;
        this.instrument = instrument;
        this.quantity = quantity;
        this.price = price;
    }

    public Integer getTradeId() {
        return tradeId;
    }

    public void setTradeId(Integer tradeId) {
        this.tradeId = tradeId;
    }

    public String getTradeRef() {
        return tradeRef;
    }

    public void setTradeRef(String tradeRef) {
        this.tradeRef = tradeRef;
    }

    public String getInstrument() {
        return instrument;
    }

    public void setInstrument(String instrument) {
        this.instrument = instrument;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}