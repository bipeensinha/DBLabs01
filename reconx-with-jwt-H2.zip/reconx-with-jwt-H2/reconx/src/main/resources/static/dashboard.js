/* ==========================================
   INITIALIZE DASHBOARD
========================================== */

window.onload = function () {

    /* Greeting */

    const hour = new Date().getHours();

    let greeting = "Welcome";

    if (hour < 12)
        greeting = "Good Morning";
    else if (hour < 17)
        greeting = "Good Afternoon";
    else
        greeting = "Good Evening";

    const title = document.getElementById("greeting");

    if (title)
        title.innerHTML = greeting + ", Admin";

    createCharts();

};


/* ==========================================
   CHARTS
========================================== */

function createCharts() {

    /* ----------------------------
       LINE CHART
    ---------------------------- */

    const lineCtx = document.getElementById("lineChart");

    if (lineCtx) {

        new Chart(lineCtx, {

            type: "line",

            data: {

                labels: [
                    "Mon",
                    "Tue",
                    "Wed",
                    "Thu",
                    "Fri"
                ],

                datasets: [{

                    label: "Trades Processed",

                    data: [
                        2100,
                        2450,
                        2300,
                        2700,
                        3000
                    ],

                    borderColor: "#0b3f91",

                    backgroundColor: "rgba(11,63,145,0.15)",

                    fill: true,

                    tension: 0.4

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false

            }

        });

    }


    /* ----------------------------
       DOUGHNUT CHART
    ---------------------------- */

    const doughnutCtx = document.getElementById("doughnutChart");

    if (doughnutCtx) {

        new Chart(doughnutCtx, {

            type: "doughnut",

            data: {

                labels: [

                    "Matched",

                    "Pending",

                    "Breaks"

                ],

                datasets: [{

                    data: [

                        12100,

                        250,

                        100

                    ],

                    backgroundColor: [

                        "#2E7D32",

                        "#F9A825",

                        "#C62828"

                    ]

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false

            }

        });

    }


    /* ----------------------------
       BAR CHART
    ---------------------------- */

    const barCtx = document.getElementById("barChart");

    if (barCtx) {

        new Chart(barCtx, {

            type: "bar",

            data: {

                labels: [

                    "JP Morgan",

                    "Goldman",

                    "HSBC",

                    "Citi",

                    "Barclays"

                ],

                datasets: [{

                    label: "Trade Volume",

                    data: [

                        3000,

                        2600,

                        1800,

                        2200,

                        1700

                    ],

                    backgroundColor: [

                        "#0b3f91",

                        "#2c5db5",

                        "#5fa8ff",

                        "#7fb3ff",

                        "#a4c8ff"

                    ]

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        display: false

                    }

                }

            }

        });

    }
/* ==========================================
   GLOBAL MARKET STATUS
========================================== */

const markets = [

    {
        market: "NYSE",
        time: "09:30 AM",
        status: "🟢 Open"
    },

    {
        market: "LSE",
        time: "02:30 PM",
        status: "🟢 Open"
    },

    {
        market: "Euronext",
        time: "03:30 PM",
        status: "🟢 Open"
    },

    {
        market: "HKEX",
        time: "09:30 PM",
        status: "🔴 Closed"
    },

    {
        market: "TSE",
        time: "10:30 PM",
        status: "🔴 Closed"
    }

];

const marketTable = document.getElementById("marketStatus");

if (marketTable) {

    markets.forEach(function (m) {

        marketTable.innerHTML += `

            <tr>

                <td>${m.market}</td>

                <td>${m.time}</td>

                <td>${m.status}</td>

            </tr>

        `;

    });

}
}