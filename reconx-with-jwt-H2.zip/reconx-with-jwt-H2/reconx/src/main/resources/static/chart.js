/* ==========================================
   CHART.JS DASHBOARD
========================================== */

function createCharts() {

    Chart.defaults.font.family = "Segoe UI";
    Chart.defaults.font.size = 13;

    /* ==========================================
       TRADE VOLUME TREND
    ========================================== */

    const lineCanvas = document.getElementById("lineChart");

    if (lineCanvas) {

        new Chart(lineCanvas, {

            type: "line",

            data: {

                labels: [
                    "Mon",
                    "Tue",
                    "Wed",
                    "Thu",
                    "Fri",
                    "Sat",
                    "Sun"
                ],

                datasets: [{

                    label: "Trades Processed",

                    data: [
                        2100,
                        2450,
                        2320,
                        2700,
                        2980,
                        2600,
                        3100
                    ],

                    borderColor: "#0b3f91",

                    backgroundColor: "rgba(11,63,145,0.15)",

                    borderWidth: 3,

                    fill: true,

                    tension: .35,

                    pointRadius: 5,

                    pointBackgroundColor: "#0b3f91"

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        position: "top"

                    }

                },

                scales: {

                    y: {

                        beginAtZero: true

                    }

                }

            }

        });

    }


    /* ==========================================
       MATCH STATUS
    ========================================== */

    const doughnutCanvas =
        document.getElementById("doughnutChart");

    if (doughnutCanvas) {

        new Chart(doughnutCanvas, {

            type: "doughnut",

            data: {

                labels: [

                    "Matched",

                    "Pending",

                    "Breaks"

                ],

                datasets: [{

                    data: [

                        12100,

                        250,

                        100

                    ],

                    backgroundColor: [

                        "#2E7D32",

                        "#FFB300",

                        "#C62828"

                    ],

                    borderWidth: 2

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                cutout: "65%",

                plugins: {

                    legend: {

                        position: "bottom"

                    }

                }

            }

        });

    }


    /* ==========================================
       COUNTERPARTY VOLUME
    ========================================== */

    const barCanvas =
        document.getElementById("barChart");

    if (barCanvas) {

        new Chart(barCanvas, {

            type: "bar",

            data: {

                labels: [

                    "JP Morgan",

                    "Goldman",

                    "HSBC",

                    "Citi",

                    "Barclays",

                    "Morgan Stanley"

                ],

                datasets: [{

                    label: "Trade Volume",

                    data: [

                        3000,

                        2700,

                        1900,

                        2400,

                        1800,

                        2100

                    ],

                    backgroundColor: [

                        "#0B3F91",

                        "#2C5DB5",

                        "#4F7EDB",

                        "#6D9EFF",

                        "#8AB8FF",

                        "#A5CEFF"

                    ],

                    borderRadius: 6

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        display: false

                    }

                },

                scales: {

                    y: {

                        beginAtZero: true

                    }

                }

            }

        });

    }

}