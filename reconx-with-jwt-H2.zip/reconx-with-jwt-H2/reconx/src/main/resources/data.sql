INSERT INTO trade
(trade_ref, trade_date, trade_time, buy_sell, instrument, quantity, price, currency,
 counterparty, trader, trade_status, source_system)
VALUES
('TRD10001','2026-07-24','09:15:00','BUY','AAPL',100,195.25,'USD',
 'Goldman Sachs','Rahul Sharma','MATCHED','Bloomberg');

INSERT INTO trade
(trade_ref, trade_date, trade_time, buy_sell, instrument, quantity, price, currency,
 counterparty, trader, trade_status, source_system)
VALUES
('TRD10002','2026-07-24','09:30:00','SELL','MSFT',200,452.50,'USD',
 'JP Morgan','Anita Gupta','MATCHED','Reuters');

INSERT INTO trade
(trade_ref, trade_date, trade_time, buy_sell, instrument, quantity, price, currency,
 counterparty, trader, trade_status, source_system)
VALUES
('TRD10003','2026-07-24','10:05:00','BUY','GOOGL',50,182.75,'USD',
 'Morgan Stanley','Vikram Rao','PENDING','Bloomberg');

INSERT INTO trade
(trade_ref, trade_date, trade_time, buy_sell, instrument, quantity, price, currency,
 counterparty, trader, trade_status, source_system)
VALUES
('TRD10004','2026-07-24','10:40:00','SELL','TSLA',75,315.40,'USD',
 'Citibank','Priya Nair','UNMATCHED','Reuters');

INSERT INTO trade
(trade_ref, trade_date, trade_time, buy_sell, instrument, quantity, price, currency,
 counterparty, trader, trade_status, source_system)
VALUES
('TRD10005','2026-07-24','11:20:00','BUY','AMZN',150,238.10,'USD',
 'HSBC','Arjun Mehta','MATCHED','Bloomberg');