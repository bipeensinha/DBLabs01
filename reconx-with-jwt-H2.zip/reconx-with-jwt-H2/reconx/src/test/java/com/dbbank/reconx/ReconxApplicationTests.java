package com.dbbank.reconx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReconxApplicationTests {

	@Test
	void contextLoads() {
	}

}
