public class Main{
    public static void main(String[] args){
        // TODO 5:
        // Create one Trade using Builder
        // Create one Trade using Factory
        // Print both objects
    }
}