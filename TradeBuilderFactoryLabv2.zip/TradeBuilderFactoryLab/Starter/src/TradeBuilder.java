public class TradeBuilder {
    // TODO 1: Add fields

    // TODO 2: Create fluent methods
    // Example:
    // public TradeBuilder tradeRef(String tradeRef){...}

    // TODO 3: Implement build()
    // Validate tradeRef and symbol
    // Return new Trade(...)

}