public class TradeFactory {
    // TODO 4:
    // Create a static createTrade() method
    // Use TradeBuilder inside the Factory
}