public class Main{
public static void main(String[] args){
Trade t1=new TradeBuilder().tradeRef("TRD1001").symbol("AAPL").quantity(100).price(180.5).build();
System.out.println(t1);
System.out.println();
Trade t2=TradeFactory.createTrade("TRD2001","IBM",50,210.75);
System.out.println(t2);
}}