public class TradeBuilder{
private String tradeRef,symbol; private int quantity; private double price;
public TradeBuilder tradeRef(String v){tradeRef=v;return this;}
public TradeBuilder symbol(String v){symbol=v;return this;}
public TradeBuilder quantity(int v){quantity=v;return this;}
public TradeBuilder price(double v){price=v;return this;}
public Trade build(){ if(tradeRef==null||symbol==null) throw new InvalidTradeException("Trade Ref and Symbol required"); return new Trade(tradeRef,symbol,quantity,price);}
}