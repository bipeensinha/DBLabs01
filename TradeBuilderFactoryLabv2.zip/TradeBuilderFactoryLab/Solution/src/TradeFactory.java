public class TradeFactory{
public static Trade createTrade(String r,String s,int q,double p){
return new TradeBuilder().tradeRef(r).symbol(s).quantity(q).price(p).build();
}}