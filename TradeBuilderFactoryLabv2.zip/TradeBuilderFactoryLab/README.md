# Builder & Factory Hands-on Lab

## Objective
Implement the missing code marked TODO.

## Exercise Steps
1. Complete TradeBuilder fields.
2. Create fluent setter methods returning TradeBuilder.
3. Implement build() with validation.
4. Implement TradeFactory.createTrade().
5. Update Main.java to test both Builder and Factory.

## Compile
Open terminal inside Starter/src

javac *.java

java Main

After completing the exercise, compare your work with the Solution folder.
