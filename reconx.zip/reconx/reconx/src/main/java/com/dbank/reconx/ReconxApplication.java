package com.dbank.reconx;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReconxApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReconxApplication.class, args);
    }

    @Bean
    CommandLineRunner demo() {
        return args -> {
            trade t = new trade("TRD1001", 250000);
            System.out.println("Trade object created.");
        };
    }
}