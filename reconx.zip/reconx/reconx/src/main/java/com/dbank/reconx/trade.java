package com.dbank.reconx;

public class trade {

        private String tradeRef;
            private double amount;

                public trade(String tradeRef, double amount) {
                            this.tradeRef = tradeRef;
                                    this.amount = amount;
                                        }
                                    
                
}